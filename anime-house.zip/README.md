# Anime House

Anime House is an E-Commerce website based in New Zealand. The main goal of this website is to sell anime products worldwide for kid.

## Installation

Use the package manager [npm](https://www.npmjs.com/) to install Anime House.

```bash
npm install
cd anime-house
npm run dev[This will run a development server locally]
```

```

## Contributing

Pull requests are welcome. For major changes, please open an issue first
to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License

[MIT](https://choosealicense.com/licenses/mit/)
